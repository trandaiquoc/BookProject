<?php
require_once 'models/Transactions.php';
require_once 'models/ZaloPay.php';
class TransactionController {
    private $transactionModel;
    private $zaloPayModel;

    public function __construct($db) {
        $this->transactionModel = new Transactions($db);
        $this->zaloPayModel = new ZaloPayModel();
    }

    public function getTransaction()
    {
        header('Content-Type: application/json; charset=UTF-8');

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            echo json_encode(['status' => 'error', 'message' => 'Phương thức không hợp lệ']);
            return;
        }
        
        $data = json_decode(file_get_contents("php://input"), true);
        $user_id = $data['user_id'];

        if (!$user_id) {
            echo json_encode(['status' => 'error', 'message' => 'Không có Mã tài khoản']);
            return;
        }
        $trans = $this->transactionModel->getAllTransaction($user_id);
        if ($trans) {
            echo json_encode(['status' => 'success', 'message' => 'Thành công', "trans" => $trans]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'không có sách nào!']);
        }

    }
    public function createTransaction()
    {
        header('Content-Type: application/json; charset=UTF-8');

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            echo json_encode(['status' => 'error', 'message' => 'Phương thức không hợp lệ']);
            return;
        }
        
        $data = json_decode(file_get_contents("php://input"), true);

        $user_id = $data['user_id'];
        if (!$user_id) {
            echo json_encode(['status' => 'error', 'message' => 'Không có Mã tài khoản']);
            return;
        }

        $book_id = $data['book_id'];
        if (!$book_id) {
            echo json_encode(['status' => 'error', 'message' => 'Không có Mã sách']);
            return;
        }

        $price = $data['price'];
        if (!$price) {
            echo json_encode(['status' => 'error', 'message' => 'Lỗi giá sản phẩm']);
            return;
        }

        $transaction_id = $this->transactionModel->createTransaction($user_id,$book_id, $price);
        if ($transaction_id) {
            echo json_encode(['status' => 'success', 'message' => 'Thành công', "transaction_id" => $transaction_id]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Lỗi tạo đơn hàng!']);
        }

    }
    public function createZaloPayOrder()
    {
        header('Content-Type: application/json; charset=UTF-8');

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            echo json_encode(['status' => 'error', 'message' => 'Phương thức không hợp lệ']);
            return;
        }
        
        $data = json_decode(file_get_contents("php://input"), true);

        $transaction_id = $data['transaction_id'];
        if (!$transaction_id) {
            echo json_encode(['status' => 'error', 'message' => 'Không có mã giao dịch']);
            return;
        }
        $zalopay_order = $this->zaloPayModel->createOrder($transaction_id);
        if ($zalopay_order) {
            echo json_encode(['status' => 'success', 'message' => 'Thành công', "checkout_url" => $zalopay_order['checkout_url']]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Lỗi Thanh Toán']);
        }

    }
    public function getNewTransaction() {
        header('Content-Type: application/json; charset=UTF-8');

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            echo json_encode(['status'=>'error','message'=>'Phương thức không hợp lệ']);
            return;
        }

        $data = json_decode(file_get_contents("php://input"), true);
        $transaction_id = intval($data['transaction_id'] ?? 0);
        $status = $data['status'] ?? '';

        if (!$transaction_id || !$status) {
            echo json_encode(['status'=>'error','message'=>'Dữ liệu không hợp lệ']);
            return;
        }

        // Map status ZaloPay sang 'success' hoặc 'failed'
        if ($status == 1) $status_db = 'success';
        else $status_db = 'failed';
        $this->transactionModel->updateStatus($transaction_id, $status_db);
        // Lấy transaction từ model
        $transaction = $this->transactionModel->getTransaction($transaction_id);
        if (!$transaction) {
            echo json_encode(['status'=>'error','message'=>'Không tìm thấy transaction']);
            return;
        }
        echo json_encode(['status'=>'success','transaction'=>$transaction]);
    }
}
?>