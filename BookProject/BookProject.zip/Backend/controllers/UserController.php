<?php
require_once 'models/Users.php';

class UserController {
    private $userModel;

    public function __construct($db) {
        $this->userModel = new Users($db);
    }

    // API đăng nhập trả về JSON
    public function login() {
        header('Content-Type: application/json; charset=UTF-8');
        
        // Chỉ nhận POST
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $data = json_decode(file_get_contents("php://input"), true);
            $username = $data['username'] ?? '';
            $password = $data['password'] ?? '';

            if (!empty($username) && !empty($password)) {
                $user = $this->userModel->authenticate($username, $password);

                if ($user) {
                    echo json_encode([
                        "status" => "success",
                        "message" => "Đăng nhập thành công!",
                        "data" => $user
                    ]);
                } else {
                    echo json_encode([
                        "status" => "error",
                        "message" => "Sai tài khoản hay mật khẩu!"
                    ]);
                }
            } else {
                echo json_encode([
                    "status" => "error",
                    "message" => "Bạn đã nhập thiếu thông tin!"
                ]);
            }
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "Lỗi đường truyền!"
            ]);
        }
    }

    public function register() {
        //Trả về dữ liệu JSON
        header('Content-Type: application/json; charset=UTF-8');

        // Chỉ nhận POST
        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            echo json_encode(['status' => 'error', 'message' => 'Phương thức không hợp lệ']);
            return;
        }
        // Nhận dữ liệu JSON
        $data = json_decode(file_get_contents("php://input"), true);
        $username = trim($data['username'] ?? '');
        $displayName = trim($data['name'] ?? '');
        $password = $data['password'] ?? '';
        $passwordAgain = $data['passwordagain'] ?? '';

        // Kiểm tra rỗng
        if (!$username || !$displayName || !$password || !$passwordAgain) {
            echo json_encode(['status' => 'error', 'message' => 'Vui lòng nhập đầy đủ thông tin']);
            return;
        }
        // Kiểm tra trùng mật khẩu
        if ($password !== $passwordAgain) {
            echo json_encode(['status' => 'error', 'message' => 'Mật khẩu nhập lại không khớp']);
            return;
        }

        // Kiểm tra username đã tồn tại chưa
        if ($this->userModel->exists($username)) {
            echo json_encode(['status' => 'error', 'message' => 'Tên tài khoản đã tồn tại']);
            return;
        }

        // Hash mật khẩu
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        // Lưu DB
        $success = $this->userModel->create($username, $hashedPassword, $displayName);

        if ($success) {
            echo json_encode(['status' => 'success', 'message' => 'Đăng ký thành công']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Lỗi hệ thống, thử lại sau']);
        }
    }
    
    public function checkUser() {
        header('Content-Type: application/json; charset=UTF-8');

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            echo json_encode(['status' => 'error', 'message' => 'Phương thức không hợp lệ']);
            return;
        }

        $data = json_decode(file_get_contents("php://input"), true);
        $username = trim($data['username'] ?? '');

        if (!$username) {
            echo json_encode(['status' => 'error', 'message' => 'Vui lòng nhập tên tài khoản']);
            return;
        }

        if ($this->userModel->exists($username)) {
            echo json_encode(['status' => 'success', 'message' => 'Tài khoản tồn tại']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Tài khoản không tồn tại']);
        }
    }
    public function resetPassword() {
        header('Content-Type: application/json; charset=UTF-8');

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            echo json_encode(['status' => 'error', 'message' => 'Phương thức không hợp lệ']);
            return;
        }

        $data = json_decode(file_get_contents("php://input"), true);
        $username = trim($data['username'] ?? '');
        $password = $data['password'] ?? '';
        $passwordAgain = $data['passwordagain'] ?? '';

        if (!$username || !$password || !$passwordAgain) {
            echo json_encode(['status' => 'error', 'message' => 'Vui lòng nhập đầy đủ thông tin']);
            return;
        }

        if ($password !== $passwordAgain) {
            echo json_encode(['status' => 'error', 'message' => 'Mật khẩu nhập lại không khớp']);
            return;
        }

        if (!$this->userModel->exists($username)) {
            echo json_encode(['status' => 'error', 'message' => 'Tài khoản không tồn tại']);
            return;
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $success = $this->userModel->updatePassword($username, $hashedPassword);

        if ($success) {
            echo json_encode(['status' => 'success', 'message' => 'Đổi mật khẩu thành công']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Không thể cập nhật mật khẩu']);
        }
    }

    public function updateProfile() {
        header('Content-Type: application/json; charset=UTF-8');

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            echo json_encode(['status' => 'error', 'message' => 'Phương thức không hợp lệ']);
            return;
        }

        $data = json_decode(file_get_contents("php://input"), true);
        $username = trim($data['username'] ?? '');
        $name = $data['name'] ?? '';
        $birthday = $data['birthday'] ?? '';
        $avatar = $data['avatar'] ?? '';
        $success = $this->userModel->updateProfile($username, $name, $birthday, $avatar);

        if ($success) {
            echo json_encode(['status' => 'success', 'message' => 'Cập nhật hồ sơ thành công']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Không thể cập nhật hồ sơ']);
        }
    }

}
?>