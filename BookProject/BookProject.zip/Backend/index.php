<?php
require_once('config/config.inc.php');

function autoloadMVC($directory)
{
    foreach (glob($directory . '/*.php') as $filename) {
        require_once($filename);
    }
}
autoloadMVC('models');
autoloadMVC('controllers');

$action = "";
$db = getDB();
$action = isset($_REQUEST["action"]) ? $_REQUEST["action"] : "home";


switch ($action) {
    case "login":
        $controller = new UserController($db);
        $controller->login();
        break;
    case "register":
        $controller = new UserController($db);
        $controller->register();
        break;
    case "checkUser":
        $controller = new UserController($db);
        $controller->checkUser();
        break;
    case "resetPassword":
        $controller = new UserController($db);
        $controller->resetPassword();
        break;
    case "updateProfile":
        $controller = new UserController($db);
        $controller->updateProfile();
        break;
    case "getUploadedBooks":
        $controller = new BookController($db,  $mongoDB);
        $controller->getUploadedBooks();
        break;
    case "getFavoritedBooks":
        $controller = new BookController($db,  $mongoDB);
        $controller->getFavoritedBooks();
        break;
    case "getBook":
        $controller = new BookController($db,  $mongoDB);
        $controller->getBookInfo();
        break;
    case "getBookComments":
        $controller = new BookController($db,  $mongoDB);
        $controller->getBookComments();
        break;
    case "submitComment":
        $controller = new BookController($db,  $mongoDB);
        $controller->submitComment();
        break;
    case "saveReadingState":
        $controller = new BookController($db,  $mongoDB);
        $controller->saveReadingState();
        break;
    case "getTransaction":
        $controller = new TransactionController($db);
        $controller->getTransaction();
        break;
    case "manageBooks":
        $controller = new BookController($db, $mongoDB);
        $controller->getAllManageBooks();
        break;
    case "saveBook":
        $controller = new BookController($db, $mongoDB);
        $controller->favoriteBook();
        break;
    case "unSaveBook":
        $controller = new BookController($db, $mongoDB);
        $controller->unFavoriteBook();
        break;
    case "createTransaction":
        $controller = new TransactionController($db);
        $controller->createTransaction();
        break;
    case "createZaloPayOrder":
        $controller = new TransactionController($db);
        $controller->createZaloPayOrder();
        break;
    case "getNewTransaction":
        $controller = new TransactionController($db);
        $controller->getNewTransaction();
        break;
    default:
        $requestUri = $_SERVER['REQUEST_URI'] ?? '';
            echo json_encode([
                "status" => "error",
                "message" => "Invalid action or API not found",
                "url_requested" => $requestUri
            ]);
        break;
}
?>