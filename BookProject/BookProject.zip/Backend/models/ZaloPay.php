<?php
class ZaloPayModel {

    public function createOrder($transaction) {
        // Thêm code gọi ZaloPay Sandbox API
        // Trả về checkout_url để redirect client
        $checkout_url = "https://sandbox.zalopay.com.vn/checkout?orderid=".$transaction['transaction_id'];
        return ['checkout_url' => $checkout_url];
    }
}
