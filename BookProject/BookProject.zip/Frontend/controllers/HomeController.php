<?php

class HomeController extends Controller {
    
    public function index()
    {
        $this->loadView('home.php');
    }
}
?>