<?php

class TransactionController extends Controller {

    private $apiGetTrans;
    private $apiCreateTrans;
    private $apiCreateZaloPayOrders;
    private $apiGetNewTrans;

    public function __construct() {
        // Đường dẫn API backend
        $this->apiGetTrans = "http://localhost/BookProject/BookProject/Backend/index.php?action=getTransaction";
        $this->apiCreateTrans = "http://localhost/BookProject/BookProject/Backend/index.php?action=createTransaction";
        $this->apiCreateZaloPayOrders = "http://localhost/BookProject/BookProject/Backend/index.php?action=createZaloPayOrder";
        $this->apiGetNewTrans = "http://localhost/BookProject/BookProject/Backend/index.php?action=getNewTransaction";
    }

    public function showTransactionHistory()
    {
        $user_id = $_SESSION['user']['user_id'];
        $response = $this->callAPIgetTrans($user_id);
        $result = json_decode($response, true);
        if ($response === false || $result === null) {
            $this->loadView('transaction.php', [
            'message' => 'Không nhận được phản hồi từ server hoặc dữ liệu không hợp lệ.',
            ]);
            return;
        }
        if (isset($result['status']) && $result['status'] === 'success') {         
           $this->loadView('transaction.php', 
            ['transactioninfo' => $result['trans'] ?? []]);
        } else {
            $this->loadView('transaction.php', ['message' => $result['message']]);
        }
    }
    private function callAPIgetTrans($userid) {
        $data = json_encode(['user_id' => $userid]);
        $ch = curl_init($this->apiGetTrans);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json']
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    public function showPayment()
    {
        $book_id = isset($_GET['book_id']) ? intval($_GET['book_id']) : 0;
        $book_name = isset($_GET['book_name']) ? $_GET['book_name'] : '';
        $price = isset($_GET['price']) ? $_GET['price'] : 0;
        $user_id = $_SESSION['user']['user_id'];
        $user_name = $_SESSION['user']['name'];
        if ($book_id <= 0) {
            $this->loadView('bookProfile.php', ['message' => 'ID sách không hợp lệ.']);
            return;
        }
        // Tạo transaction pending
        $response = $this->callAPIcreateTrans($user_id, $book_id,  $price);
        $result = json_decode($response, true);
        if ($response === false || $result === null) {
            $this->loadView('bookProfile.php', [
            'message' => 'Không nhận được phản hồi từ server hoặc dữ liệu không hợp lệ.',
            ]);
            return;
        }
        if (isset($result['status']) && $result['status'] === 'success') {         
          $this->loadView('payment.php',
                    ['book_id' => $book_id,
                            'book_name' => $book_name,
                            'price' => $price,
                            'user_id' => $user_id,
                            'user_name' => $user_name,
                            'transaction_id' => $result['transaction_id']]);
        } else {
            $this->loadView('bookProfile.php', ['message' => $result['message']]);
        }
    }
    private function callAPIcreateTrans($userid, $book_id, $price) {
        $data = json_encode(['user_id' => $userid, 'book_id' => $book_id, 'price' => $price]);
        $ch = curl_init($this->apiCreateTrans);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json']
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
    public function processZaloPay()
    {
        $transaction_id = isset($_GET['transaction_id']) ? intval($_GET['transaction_id']) : 0;
        if ($transaction_id <= 0) {
            $this->loadView('bookProfile.php', ['message' => 'ID hóa đơn không hợp lệ.']);
            return;
        }
        // Tạo transaction pending
        $response = $this->createZaloPayOrder($transaction_id);
        $result = json_decode($response, true);

        if (isset($result['status']) && $result['status'] === 'success') {
            header("Location: ".$result['checkout_url']);
            exit;
        } else {
            $this->loadView('bookProfile.php', ['message' => $result['message'] ?? 'Lỗi tạo đơn ZaloPay']);
        }
    }
    private function createZaloPayOrder($transaction_id) {
        $data = json_encode(['transaction_id' => $transaction_id]);
        $ch = curl_init($this->apiCreateZaloPayOrders);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json']
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    public function paymentResult() {
        $transaction_id = intval($_GET['transaction_id'] ?? 0);
        $status = $_GET['status'] ?? '';
        if ($transaction_id <= 0) {
            $this->loadView('bookProfile.php', ['message'=>'ID giao dịch không hợp lệ']);
            return;
        }

        // Gọi backend lấy transaction
        $response  = $this->callAPIUpdateStatus($transaction_id, $status);
        $transaction = json_decode($response, true)['transaction'] ?? [];
        $this->loadView('paymentResult.php', ['transaction' => $transaction]);
    }

    private function callAPIUpdateStatus($transaction_id, $status) {
        $data = json_encode(['transaction_id' => $transaction_id, 'status' => $status]);
        $ch = curl_init($this->apiGetNewTrans);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json']
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    
}
?>