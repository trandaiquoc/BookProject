<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kết quả thanh toán</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f0; padding: 50px; }
        .container { max-width: 600px; margin: auto; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #485550; }
        p { font-size: 1.2rem; margin: 10px 0; }
        .success { color: green; font-weight: bold; }
        .failed { color: red; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <h2>Kết quả thanh toán</h2>
    <p><strong>Sách:</strong> <?= htmlspecialchars($transaction['book_name']) ?></p>
    <p><strong>Người dùng:</strong> <?= htmlspecialchars($transaction['user_name']) ?></p>
    <p><strong>Giá:</strong> <?= number_format($transaction['amount'],0,',','.') ?> VNĐ</p>
    <p><strong>Trạng thái:</strong> 
        <?php if($transaction['status'] === 'success'): ?>
            <span class="success">Thành công</span>
        <?php elseif($transaction['status'] === 'failed'): ?>
            <span class="failed">Thất bại</span>
        <?php else: ?>
            <?= htmlspecialchars($transaction['status']) ?>
        <?php endif; ?>
    </p>
</div>
</body>
</html>
