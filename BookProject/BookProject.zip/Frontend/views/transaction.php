<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="public/css/transaction.css">
</head>
<body>
    <?php if($transactioninfo): ?>
        <?php foreach ($transactioninfo as $i=>$t): ?>
        <div class="transaction-item">
            <div class="top-row">
                <span class="left"><strong>Người thanh toán: </strong><?= htmlspecialchars($t['username']) ?></span>
                <span class="right"><strong>Tên sách: </strong><?= htmlspecialchars($t['bookname']) ?></span>
            </div>
            <div class="middle-row">
                <span class="left"><strong>Tổng thanh toán: </strong><?= number_format($t['amount'], 0, ',', '.') ?> VNĐ</span>
                <span class="right"><strong>Thời gian: </strong><?= htmlspecialchars($t['created_at']) ?></span>
            </div>
            <div class="bottom-row">
                <span class="status <?= htmlspecialchars($t['status']) ?>"><?= htmlspecialchars($t['status']) ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p> Hiện chưa có giao dịch!</p>
    <?php endif; ?>
<?php if (isset($message)): ?>
    <p style="color: red;"><?php echo $message; ?></p>
<?php endif; ?>  
</body>