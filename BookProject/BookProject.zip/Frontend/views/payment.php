<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="public/css/payment.css">

</head>

<body>
<div class="container">
    <div class="left">
        <h2>Thông tin thanh toán</h2>
        <p><strong>Sách:</strong> <?= htmlspecialchars($book_name) ?></p>
        <p><strong>Người dùng:</strong> <?= htmlspecialchars($user_name) ?></p>
        <p><strong>Giá:</strong> <?= number_format($price,0,',','.') ?> VNĐ</p>
    </div>
    <div class="right">
        <h2>Thanh toán ZaloPay Sandbox</h2>
        <a class="btn-zalopay" href="index.php?action=processZaloPay&transaction_id=<?= $transaction_id ?>">Thanh toán</a>
    </div>
</div>
</body>
</html>